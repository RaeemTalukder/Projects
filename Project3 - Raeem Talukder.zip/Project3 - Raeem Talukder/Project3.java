


import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;


public class Project3 {
    static int[][] m;
    static int[][] dp;
    static int row, col;

    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("input3.txt");
        Scanner scan = new Scanner(file);
        //read max rows and columns
        row = scan.nextInt();
        col = scan.nextInt();
        m = new int[row][col];
        dp = new int[row][col];


        // Read matrix
        for (int i = 0; i < row; i++)
            for (int j = 0; j < col; j++)
                m[i][j] = scan.nextInt();

        int maxLength = 0;

        // Try starting from every cell check possible lengths till it finds the maximum length out of each test.
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                int currentLength = dpf(i, j);
                if (currentLength > maxLength) {
                    maxLength = currentLength;
                }
            }
        }

        System.out.println(maxLength); //print max array
    }

    static int dpf(int i, int j) {
        if (dp[i][j] != 0) return dp[i][j]; // 0 means uncomputed
        int max = 1;

        // Move to the right if it hits a dead end then stop and return the number of moves
        if (j + 1 < col && m[i][j + 1] < m[i][j]) {
            int right = 1 + dpf(i, j + 1);
            if (right > max) {
                max = right;
            }
        }

        // Move down in the array and if it hits a end then stop and return number of moves
        if (i + 1 < row && m[i + 1][j] < m[i][j]) {
            int down = 1 + dpf(i + 1, j);
            if (down > max) {
                max = down;
            }
        }

        dp[i][j] = max; //*important* stores previous results so it isn't brute forcing.
        return max; //gives max to system.out
    }
}
