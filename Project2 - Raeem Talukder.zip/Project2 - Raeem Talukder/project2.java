package project.pkg2;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class project2 {

    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("input2.txt"); // scan file
        Scanner input = new Scanner(file);
        int row = input.nextInt();
        int col = input.nextInt();
        int target = input.nextInt();
        int array[][] = new int[row][col];//set array parameters

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                array[i][j] = input.nextInt();//insert numbers into array
            }
        }

        if (searcharray(array, target, 0, array.length - 1, 0, array[0].length - 1) == false) {
            System.out.println("Target not found.");
        }//if number isn't found produce prompt that target isn't found
    }

    static boolean searcharray(int[][] array, int target, int rowStart, int rowEnd, int colStart, int colEnd) {

        if (rowStart > rowEnd || colStart > colEnd) {
            return false;
        } //if number being found is outside either row or coloumn bounds return false

        int midRow = rowStart + (rowEnd - rowStart) / 2;//divide row by half
        int midCol = colStart + (colEnd - colStart) / 2; // divide column by half
        int midVal = array[midRow][midCol]; //mid value will be our search element to comparing to our target.

        if (midVal == target) {
            midRow++; // to get the row accurate since they all start at 0
            midCol++;  // to get the row accurate since they all start at 0
            System.out.println("Target found at: ");
            System.out.println(midRow + " " + midCol); //when mid value is equal to our target print out the element row and column it was found in
            return true; // end reccursive loop
        }

        if (midVal < target) {//
            //check top right and break reccursive loop if target found
            if (inRange(array, target, rowStart, midRow, midCol + 1, colEnd)
                    && searcharray(array, target, rowStart, midRow, midCol + 1, colEnd)) {
                return true;
            }
            // check bottom left and break reccursive loop if target found
            if (inRange(array, target, midRow + 1, rowEnd, colStart, midCol)
                    && searcharray(array, target, midRow + 1, rowEnd, colStart, midCol)) {
                return true;
            }
            //check bottom right and break reccursive loop if target found
            if (inRange(array, target, midRow + 1, rowEnd, midCol + 1, colEnd)
                    && searcharray(array, target, midRow + 1, rowEnd, midCol + 1, colEnd)) {
                return true;
            }
        } else {
            //check top left and break reccursive loop if target found
            if (inRange(array, target, rowStart, midRow - 1, colStart, midCol - 1)
                    && searcharray(array, target, rowStart, midRow - 1, colStart, midCol - 1)) {
                return true;
            }
            //check top right and break reccursive loop if target found
            if (inRange(array, target, rowStart, midRow - 1, midCol, colEnd)
                    && searcharray(array, target, rowStart, midRow - 1, midCol, colEnd)) {
                return true;
            }
            //check bottom left and break reccursive loop if target found
            if (inRange(array, target, midRow, rowEnd, colStart, midCol - 1)
                    && searcharray(array, target, midRow, rowEnd, colStart, midCol - 1)) {
                return true;
            }
        }

        return false; //return false if target isn't found in array
    }

    static boolean inRange(int[][] array, int target, int rowStart, int rowEnd, int colStart, int colEnd) {
        if (rowStart > rowEnd || colStart > colEnd) {
            return false;
        } //to stop processing invalud ranges, was having problems as the subarray kept printing even though target was found, this prevents that

        printSubarray(array, rowStart, rowEnd, colStart, colEnd); //print a sub array that is being split

        int min = array[rowStart][colStart];
        int max = array[rowEnd][colEnd];

        return target >= min && target <= max; //retun true if set target is in range.
    }

    static void printSubarray(int[][] array, int rowStart, int rowEnd, int colStart, int colEnd) {//whatever subarray is being scanned print it out
        System.out.println("Subarray:"); 
        for (int i = rowStart; i <= rowEnd; i++) {
            for (int j = colStart; j <= colEnd; j++) {

                System.out.print(array[i][j] + " ");
            }
            System.out.println();
        }
    }
}
